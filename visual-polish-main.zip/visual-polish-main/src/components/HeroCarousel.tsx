import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Shield } from "lucide-react";
import heroImg1 from "@/assets/brand-logo.jpeg";
import heroImg2 from "@/assets/hero-2.jpeg";
import heroImg3 from "@/assets/hero-3.jpeg";

const slides = [
  {
    image: heroImg1,
    title: "Documentação veicular",
    highlight: "sem complicação",
    subtitle: "Regularize seu veículo com quem entende. Atendimento ágil, transparente e 100% confiável.",
  },
  {
    image: heroImg2,
    title: "Faça a sua",
    highlight: "regularização!",
    subtitle: "Seu veículo regularizado em boas mãos. Qualidade, confiança e excelência.",
  },
  {
    image: heroImg3,
    title: "Precisa regularizar",
    highlight: "seu veículo?",
    subtitle: "Faça o seu orçamento conosco! Entre em contato agora mesmo.",
  },
];

const HeroCarousel = () => {
  const [current, setCurrent] = useState(0);

  const next = useCallback(() => setCurrent((p) => (p + 1) % slides.length), []);
  const prev = useCallback(() => setCurrent((p) => (p - 1 + slides.length) % slides.length), []);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, [next]);

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background images */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0"
        >
          <img
            src={slides[current].image}
            alt=""
            className="w-full h-full object-cover"
            width={1920}
            height={1080}
          />
          <div className="absolute inset-0 bg-deep/80" />
        </motion.div>
      </AnimatePresence>

      {/* Content */}
      <div className="container relative z-10 py-32">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 mb-6"
          >
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-primary-foreground text-sm font-semibold">Referência em Itabuna - BA</span>
          </motion.div>

          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-4">
                <span className="text-primary-foreground">{slides[current].title} </span>
                <span className="text-gradient">{slides[current].highlight}</span>
              </h1>
              <p className="text-primary-foreground/75 text-lg md:text-xl max-w-lg mb-8">
                {slides[current].subtitle}
              </p>
            </motion.div>
          </AnimatePresence>

          <div className="flex flex-wrap gap-3">
            <a
              href="https://wa.me/5573988378774?text=Olá!%20Vim%20pelo%20site%20e%20gostaria%20de%20um%20orçamento."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-brand-gradient text-primary-foreground px-7 py-4 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.111.553 4.094 1.515 5.815L.05 23.5l5.832-1.529A11.95 11.95 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.75c-1.876 0-3.628-.52-5.124-1.424l-.368-.218-3.81.999 1.016-3.712-.24-.379A9.692 9.692 0 012.25 12C2.25 6.615 6.615 2.25 12 2.25S21.75 6.615 21.75 12 17.385 21.75 12 21.75z"/></svg>
              Solicitar Orçamento
            </a>
            <a
              href="#servicos"
              className="inline-flex items-center gap-2 border border-primary-foreground/30 text-primary-foreground px-7 py-4 rounded-2xl font-bold hover:bg-primary-foreground/10 transition-all"
            >
              Conhecer Serviços
            </a>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-6 mt-10 glass rounded-2xl px-6 py-4 w-fit">
            <div className="text-center">
              <span className="block text-primary-foreground font-extrabold text-2xl">+500</span>
              <span className="text-primary-foreground/70 text-xs">Clientes</span>
            </div>
            <div className="w-px h-8 bg-primary-foreground/20" />
            <div className="text-center">
              <span className="block text-primary-foreground font-extrabold text-2xl">100%</span>
              <span className="text-primary-foreground/70 text-xs">Regularizados</span>
            </div>
            <div className="w-px h-8 bg-primary-foreground/20" />
            <div className="text-center">
              <span className="block text-primary-foreground font-extrabold text-2xl">5★</span>
              <span className="text-primary-foreground/70 text-xs">Avaliação</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex items-center gap-4">
        <button onClick={prev} className="glass rounded-full p-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors" aria-label="Anterior">
          <ChevronLeft size={20} />
        </button>
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className={`rounded-full transition-all ${
                i === current ? "w-8 h-2 bg-primary" : "w-2 h-2 bg-primary-foreground/40"
              }`}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
        <button onClick={next} className="glass rounded-full p-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors" aria-label="Próximo">
          <ChevronRight size={20} />
        </button>
      </div>
    </section>
  );
};

export default HeroCarousel;
